﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Phonebook
{
    class Book
    {
        private List<Contact> _contacts { get; set; } = new List<Contact>();

        private void DisplayDetails(Contact contact)
        {

            Console.WriteLine($"Bulunan kayıt: İsim:{contact.Name},Soyisim:{contact.Surname},Numara:{contact.Number}");
        }


        private void DisplayDetails(List<Contact> contacts)
        {

            foreach (var contact in contacts)
            {
                DisplayDetails(contact);
            }


        }


        public void AddContact(Contact contact)
        {

            _contacts.Add(contact);
        }


        public void DisplayContact(string number)
        {
            var contact = _contacts.FirstOrDefault(c => c.Number == number);
            if (contact == null)
            {
                Console.WriteLine("Kayıt bulunamadı");

            }
            else
            {

                DisplayDetails(contact);
            }

        }



        public void DisplayAll()
        {

            DisplayDetails(_contacts);

        }
        public void DisplayMatched(string search)
        {

            var matching = _contacts.Where(c => c.Name.Contains(search)).ToList();

            if (matching.Count == 0)
            {
                Console.WriteLine("Kayıt bulunamadı");
            }
            else
            {

                DisplayDetails(matching);
            }
        }

        public void DisplayMatchedS(string search)
        {

            var matchingS = _contacts.Where(c => c.Surname.Contains(search)).ToList();

            if (matchingS.Count == 0)
            {
                Console.WriteLine("Kayıt bulunamadı");
            }
            else
            {

                DisplayDetails(matchingS);
            }
        }


    }
}
